import React, { useEffect, useState } from 'react'
import Gs from '../theme/globalStyles' 
import styled from 'styled-components'
import { Link, NavLink } from 'react-router-dom' 
import { withRouter } from 'react-router' 

import Media from '../theme/media-breackpoint' 

import Logo from '../assets/images/logo.svg'
import Menu from '../assets/images/menu.svg'
import Cross from '../assets/images/cross.svg'
import TeleICO from '../assets/images/telegram.svg'
import TwitICO from '../assets/images/twitter.svg'
import GitICO from '../assets/images/github.svg'
import Sphere from '../assets/images/menu-sphere.png'


function Header(props) { 
  const [menuShow, setOpen] = React.useState(true);
  
  useEffect(() => { 
  }, []); 
  
  return (
    <>
      <MheadBX className={` ${!menuShow ? 'show' : ''}`}> 
            <LogoM> <img  src={Logo}  alt='Hepton' /> </LogoM> 
            <Link onClick={() => setOpen(!menuShow)} to='' className='MenuICO' >
              <img className='menu' src={Menu} alt='menu' /> 
              <img className='cross' src={Cross} alt='menu' />
            </Link> 
            <HeadLinkBX>
            <Link to=''><img src={TeleICO} alt='menu' /></Link>
            <Link to=''><img src={TwitICO} alt='menu' /></Link>
            <Link to=''><img src={GitICO} alt='menu' /></Link>
            </HeadLinkBX>
      </MheadBX>
      <MainMenu className={` ${!menuShow ? 'show' : ''}`}>
        <div className='container'>
          <section>
            <Link to=''>Home</Link>
            <Link to=''>Developer</Link>
            <Link to=''>Litepaper</Link>
            <Link to=''>Blog</Link>
            <Link to=''>Grants Application</Link>
          </section>
          <section>
            <Link to=''>Careers</Link>
            <Link to=''>FAQ</Link>
            <Link to=''>Block Explorer</Link>
            <Link to=''>Testnet Faucet</Link>
          </section>
          <p>Copyright © Hepton 2022</p>
        </div>
      </MainMenu>
    </>
  )

}
const FlexDiv = styled.div`
  display: flex; align-items: center; justify-content:center; flex-wrap:wrap;
`;
const MheadBX = styled(FlexDiv)`
  width:100%;  padding:30px 0; max-width:1200px; margin:0 auto; position: relative; z-index: 101;
  @media screen and (max-width: 1200px) {
    padding: 24px;
  }

  .menu {}
  .cross {display: none;}
  &.show {
    position: fixed; left: 0; right: 0;
    .menu {display: none;}
    .cross {display: block;}
  }
  .MenuICO{ margin:0 auto; display:inline-block; position: absolute;  left: 50%;  transform: translateX(-50%);
    @media screen and (max-width: 768px) {
      position: static; margin: 0; transform: translateX(0);
    }
  }
`

const LogoM = styled(FlexDiv)`
  margin:0 auto 0 0; justify-content:space-between; 
`
const HeadLinkBX = styled(FlexDiv)` 
    a{ display: inline-block; margin-left:14px; :hover{opacity:0.8}}
    @media screen and (max-width: 768px) {display: none;}
`
const MainMenu = styled.div` 
  background: url(${Sphere}) no-repeat bottom right #000; position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 100; padding: 225px 0 0; display: none;
  section {
    padding-right: 174px; display: inline-block; vertical-align: top;
    a {display: table; color: #FFFFFF; font-size: 24px; margin-bottom: 24px;}
    a:hover {color: #F68C20;}
  }
  p {position: absolute; bottom: 60px; margin: 0;}
  .container {width:100%;  padding:30px 0; max-width:1200px; margin:0 auto;}
  &.show {display: block;}
  @media screen and (max-width: 1200px) {
    padding: 225px 24px 0;
  }
  @media screen and (max-width: 991px) {
    padding: 125px 24px 60px; background: #000;
    section {
      width: 48%; padding-right: 74px;
      a {margin-bottom: 15px; font-size: 18px;}
    }
    p {bottom: 20px;}
    .container {max-height: calc(100vh - 185px); overflow: auto;}
  }
  @media screen and (max-width: 768px) {
    section {
      width: 100%; padding-right: 74px; padding-bottom: 30px;
      a {margin-bottom: 15px; font-size: 18px;}
    }
  }
`

export default Header;
