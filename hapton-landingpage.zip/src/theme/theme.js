// import DarkBG from '../assets/images/body-bg.jpg' 

export const theme = (isDarkTheme) => {
    return {
        // text colors
        color01: isDarkTheme ? '#b19090' : '#575757',
        DownldBTNC: isDarkTheme ? '#475099' : '#475099', 
 
        
    }
}